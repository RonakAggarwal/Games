def isFull(board):
    for i in range(9):
        for j in range(9):
            if board[i][j]==0:
                return False
    return True
def findPossibleValues(board, i, j):
    possibleArray={}
    for x in range(1,10):
        possibleArray[x]=0
    #checking row
    for x in range(9):
        if board[i][x]!=0:
            possibleArray[board[i][x]]=1
    #checking columns
    for x in range(9):
        if board[x][j]!=0:
            possibleArray[board[x][j]]=1
    l=0
    m=0
    if(i>=0 and i<=2):
        l=0
    elif(i>=3 and i<=5):
        l=3
    else:
        l=6
    if(j>=0 and j<=2):
        m=0
    elif(j>=3 and j<=5):
        m=3
    else:
        m=6
    for x in range(l,l+3):
        for y in range(m,m+3):
            if board[x][y]!=0:
                possibleArray[board[x][y]]=1
    for x in range(1,10):
        if possibleArray[x]==0:
            possibleArray[x]=x
        else:
            possibleArray[x]=0
    return possibleArray

def solveSudoku(board):
    if isFull(board):
        print("solved successfully")
        printBoard(board)
        return
    else:
        for x in range(9):
            for y in range(9):
                if board[x][y]==0:
                    i=x
                    j=y
                    break
        possibleValues=findPossibleValues(board,i,j)
        for x in range(1,10):
            if possibleValues[x]!=0:
                board[i][j]=possibleValues[x]
                solveSudoku(board)
        board[i][j]=0
        
def printBoard(board):
    for i in board:
        print(i)
    
def main():
    #reading input from file
    f=open("input.txt")
    temp=f.readlines()
    temp1=[]
    for i in range(9):
        temp1.append(temp[i].split(' '))
    sudokuBoard = [[0 for x in range(9)] for x in range(9)]
    for i in range(9):
        for j in range(9):
            sudokuBoard[i][j]=int(temp1[i][j])
    printBoard(sudokuBoard)
    solveSudoku(sudokuBoard)
    
if __name__=="__main__":
    main()